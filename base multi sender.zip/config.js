module.exports = {
  BOT_TOKEN: "TOKEN",
  OWNER_ID: ["IDOWNER"],
};